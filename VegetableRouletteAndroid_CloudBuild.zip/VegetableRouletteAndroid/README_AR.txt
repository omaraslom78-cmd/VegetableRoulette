روليت الخضار - مشروع Android

المشروع يحتوي على تطبيق Android بسيط يعرض اللعبة محلياً داخل WebView.
لا يحتاج إلى اتصال إنترنت أثناء الاستخدام، ولا يتصل ببيجو لايف.

لبناء APK:
1) ثبّت Android Studio على كمبيوتر.
2) افتح Android Studio واختر Open ثم اختر مجلد VegetableRoulette.
3) انتظر Gradle Sync وثبّت Android SDK Platform 35 إذا طُلب.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد ملف APK غالباً في:
   app/build/outputs/apk/debug/app-debug.apk
6) انقل APK إلى هاتف Android وافتحه. إذا طُلب، اسمح بالتثبيت من هذا المصدر.

ملاحظات:
- هذه نسخة أولية 1.0.
- تعديل الخضار والأوزان والمضاعفات والتوقيت متاح من واجهة اللعبة.
- وضع "نتيجة محددة من الإدارة" يخص المحاكاة المحلية فقط.
- إعدادات اللعبة تُحفظ محلياً في مساحة تخزين WebView.
- لم يتم تضمين APK جاهز؛ بيئة الإنشاء الحالية لا تحتوي على Android SDK أو Gradle.


بناء APK عبر GitHub Actions من الهاتف:
- ارفع محتويات هذا المشروع إلى مستودع GitHub جديد باسم VegetableRoulette.
- من تبويب Actions فعّل workflows إذا طلب GitHub ذلك.
- شغّل workflow باسم Build Android APK عبر Run workflow.
- بعد انتهاء المهمة افتحها ونزّل artifact باسم vegetable-roulette-apk.
- فك ضغط artifact لتحصل على app-debug.apk.
